from flask import Flask, render_template, request, redirect, url_for, flash, send_file, jsonify, Response
import sqlite3
import csv
import io
import qrcode
from qrcode.image.svg import SvgImage
import base64
from datetime import datetime
import os

app = Flask(__name__)
app.secret_key = 'your-secret-key-here'  # Change this in production

# Database initialization
def init_db():
	conn = sqlite3.connect('contacts.db')
	c = conn.cursor()

	# Create contacts table
	c.execute('''
		CREATE TABLE IF NOT EXISTS contacts (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			full_name TEXT NOT NULL,
			address TEXT,
			phone_number TEXT,
			website TEXT,
			social_media_handle TEXT,
			category TEXT,
			created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
		)
	''')

	conn.commit()
	conn.close()

def get_db_connection():
	conn = sqlite3.connect('contacts.db')
	conn.row_factory = sqlite3.Row
	return conn

@app.route('/')
def index():
	conn = get_db_connection()

	# Get all contacts
	contacts = conn.execute('''
		SELECT * FROM contacts ORDER BY full_name
	''').fetchall()

	# Get all categories
	categories = conn.execute('''
		SELECT DISTINCT category FROM contacts WHERE category IS NOT NULL ORDER BY category
	''').fetchall()

	conn.close()

	return render_template('index.html', contacts=contacts, categories=categories)

@app.route('/add', methods=['GET', 'POST'])
def add_contact():
	if request.method == 'POST':
		full_name = request.form['full_name']
		address = request.form['address']
		phone_number = request.form['phone_number']
		website = request.form['website']
		social_media_handle = request.form['social_media_handle']
		category = request.form['category']

		if not full_name:
			flash('Full name is required!', 'error')
			return redirect(url_for('add_contact'))

		conn = get_db_connection()
		conn.execute('''
			INSERT INTO contacts (full_name, address, phone_number, website, social_media_handle, category)
			VALUES (?, ?, ?, ?, ?, ?)
		''', (full_name, address, phone_number, website, social_media_handle, category))
		conn.commit()
		conn.close()

		flash('Contact added successfully!', 'success')
		return redirect(url_for('index'))

	return render_template('add_contact.html')

@app.route('/edit/<int:contact_id>', methods=['GET', 'POST'])
def edit_contact(contact_id):
	conn = get_db_connection()

	if request.method == 'POST':
		full_name = request.form['full_name']
		address = request.form['address']
		phone_number = request.form['phone_number']
		website = request.form['website']
		social_media_handle = request.form['social_media_handle']
		category = request.form['category']

		if not full_name:
			flash('Full name is required!', 'error')
			return redirect(url_for('edit_contact', contact_id=contact_id))

		conn.execute('''
			UPDATE contacts
			SET full_name = ?, address = ?, phone_number = ?, website = ?, social_media_handle = ?, category = ?, updated_at = CURRENT_TIMESTAMP
			WHERE id = ?
		''', (full_name, address, phone_number, website, social_media_handle, category, contact_id))
		conn.commit()
		conn.close()

		flash('Contact updated successfully!', 'success')
		return redirect(url_for('index'))

	contact = conn.execute('SELECT * FROM contacts WHERE id = ?', (contact_id,)).fetchone()
	conn.close()

	if contact is None:
		flash('Contact not found!', 'error')
		return redirect(url_for('index'))

	return render_template('edit_contact.html', contact=contact)

@app.route('/delete/<int:contact_id>')
def delete_contact(contact_id):
	conn = get_db_connection()
	conn.execute('DELETE FROM contacts WHERE id = ?', (contact_id,))
	conn.commit()
	conn.close()

	flash('Contact deleted successfully!', 'success')
	return redirect(url_for('index'))

@app.route('/qr/<int:contact_id>')
def generate_qr(contact_id):
	conn = get_db_connection()
	contact = conn.execute('SELECT * FROM contacts WHERE id = ?', (contact_id,)).fetchone()
	conn.close()

	if contact is None:
		flash('Contact not found!', 'error')
		return redirect(url_for('index'))

	# Create contact data for QR code (only specified fields)
	contact_data = f"""CONTACT INFORMATION
Full Name: {contact['full_name']}
Address: {contact['address'] or 'N/A'}
Phone: {contact['phone_number'] or 'N/A'}
Website: {contact['website'] or 'N/A'}
Social Media: {contact['social_media_handle'] or 'N/A'}"""

	# Generate QR code
	qr = qrcode.QRCode(
		version=1,
		error_correction=qrcode.constants.ERROR_CORRECT_L,
		box_size=10,
		border=4,
	)
	qr.add_data(contact_data)
	qr.make(fit=True)

	img = qr.make_image(fill_color="black", back_color="white")

	# Convert to base64 for embedding in HTML
	buffered = io.BytesIO()
	img.save(buffered, format="PNG")
	img_str = base64.b64encode(buffered.getvalue()).decode()

	return render_template('view_qr.html', contact=contact, qr_code=img_str)

@app.route('/export')
def export_contacts():
    # Fetch contacts
    with get_db_connection() as conn:
        contacts = conn.execute(
            'SELECT * FROM contacts ORDER BY full_name'
        ).fetchall()

    # Create CSV in memory
    output = io.StringIO(newline="")
    fieldnames = ['Full Name', 'Address', 'Phone Number', 'Website', 'Social Media Handle']
    writer = csv.DictWriter(output, fieldnames=fieldnames)

    writer.writeheader()
    for contact in contacts:
        writer.writerow({
            'Full Name': contact['full_name'],
            'Address': contact['address'],
            'Phone Number': contact['phone_number'],
            'Website': contact['website'],
            'Social Media Handle': contact['social_media_handle']
        })

    # Reset buffer
    output.seek(0)

    # Prepare filename with timestamp
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f'contacts_export_{timestamp}.csv'

    # Send as downloadable CSV
    return Response(
        output.getvalue().encode('utf-8-sig'),
        mimetype="text/csv",
        headers={
            "Content-Disposition": f"attachment; filename={filename}"
        }
    )

@app.route('/import', methods=['GET', 'POST'])
def import_contacts():
    if request.method == 'POST':
        if 'csv_file' not in request.files:
            flash('No file selected!', 'error')
            return redirect(url_for('import_contacts'))

        file = request.files['csv_file']
        if file.filename == '':
            flash('No file selected!', 'error')
            return redirect(url_for('import_contacts'))

        if file and file.filename.endswith('.csv'):
            try:
                stream = io.StringIO(file.stream.read().decode("utf-8-sig"), newline=None)
                csv_input = csv.reader(stream)

                # Skip header
                next(csv_input, None)

                conn = get_db_connection()
                imported_count = 0

                for row in csv_input:
                    if len(row) >= 5:  # Expecting exactly 5 fields
                        full_name, address, phone_number, website, social_media_handle = row[:5]

                        if full_name.strip():  # Only import if full name is not empty
                            conn.execute('''
                                INSERT INTO contacts (full_name, address, phone_number, website, social_media_handle)
                                VALUES (?, ?, ?, ?, ?)
                            ''', (full_name.strip(), address, phone_number, website, social_media_handle))
                            imported_count += 1

                conn.commit()
                conn.close()

                flash(f'Successfully imported {imported_count} contacts!', 'success')
                return redirect(url_for('index'))

            except Exception as e:
                flash(f'Error importing file: {str(e)}', 'error')
                return redirect(url_for('import_contacts'))

        else:
            flash('Please upload a valid CSV file!', 'error')
            return redirect(url_for('import_contacts'))

    return render_template('import_contacts.html')

@app.route('/categories')
def get_categories():
	conn = get_db_connection()
	categories = conn.execute('''
		SELECT DISTINCT category FROM contacts
		WHERE category IS NOT NULL AND category != ''
		ORDER BY category
	''').fetchall()
	conn.close()

	category_list = [cat['category'] for cat in categories]
	return jsonify(category_list)

if __name__ == '__main__':
	init_db()
	app.run(debug=True)
